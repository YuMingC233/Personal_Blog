create definer = root@localhost view blogcommentlist as
select `bc`.`userName`        AS `userName`,
       `bc`.`userID`          AS `userID`,
       `ct`.`MainText`        AS `MainText`,
       `bc`.`publishTime`     AS `publishTime`,
       `bc`.`blogID`          AS `blogID`,
       `bc`.`likeNum`         AS `likeNum`,
       `bc`.`citedCommentNum` AS `citedCommentNum`
from `yumingblog_db`.`blogcomment` `bc`
         join `yumingblog_db`.`commenttext` `ct`
where (`bc`.`ID` = `ct`.`ID`);

-- comment on column blogcommentlist.评论人 not supported: 用户名称，不可为空

-- comment on column blogcommentlist.评论人QQ账号 not supported: 用户ID，不可为空,使用字符串存储

-- comment on column blogcommentlist.评论正文 not supported: 评论正文

-- comment on column blogcommentlist.评论时间 not supported: 发表评论时的时间

-- comment on column blogcommentlist.前台地址 not supported: 被发表评论的BlogID

-- comment on column blogcommentlist.喜欢数 not supported: 喜欢数量

-- comment on column blogcommentlist.被评论数量 not supported: 被评论数

