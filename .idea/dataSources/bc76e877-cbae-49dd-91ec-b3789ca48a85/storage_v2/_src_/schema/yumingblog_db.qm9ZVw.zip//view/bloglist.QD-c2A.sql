create definer = root@localhost view bloglist as
select `yumingblog_db`.`bloginfo`.`Title`          AS `Title`,
       `yumingblog_db`.`bloginfo`.`TagsID`         AS `TagsID`,
       `yumingblog_db`.`bloginfo`.`ReadNum`        AS `ReadNum`,
       `yumingblog_db`.`bloginfo`.`CommentNum`     AS `CommentNum`,
       `yumingblog_db`.`bloginfo`.`PublishTime`    AS `PublishTime`,
       `yumingblog_db`.`bloginfo`.`LastUpdateTime` AS `LastUpdateTime`
from `yumingblog_db`.`bloginfo`;

-- comment on column bloglist.标题 not supported: 博客标题，不为空

-- comment on column bloglist.相关标签 not supported: 标签ID集合，使用英文符,分割

-- comment on column bloglist.浏览量 not supported: 浏览数量

-- comment on column bloglist.评论量 not supported: 评论数量

-- comment on column bloglist.发布时间 not supported: 发布时间

-- comment on column bloglist.最后一次更新时间 not supported: 最后一次修改时间

