create definer = root@localhost view taglist as
select `yumingblog_db`.`tag`.`Name` AS `Name`
from `yumingblog_db`.`tag`;

-- comment on column taglist.标签名称 not supported: 标签名称

